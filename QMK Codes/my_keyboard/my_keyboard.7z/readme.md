# QT_Keypad

A standard 17-key numpad in 5x4 config, num lock indicator LED, and a media volume knob. An Arduino Pro Micro (Atmega32u4 5V 16Mhz) is used as the MCU.

* Author: [Quang Truong](https://github.com/lquang4321)
* Version: 1

Make example:

    make my_keyboard:default
